from django.contrib import admin


from .models import Registerpatient, Patientbank, Timeprocessing

admin.site.register(Registerpatient)
admin.site.register(Patientbank)
admin.site.register(Timeprocessing)

# Register your models here.
