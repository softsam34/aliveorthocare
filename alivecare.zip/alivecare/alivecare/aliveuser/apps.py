from django.apps import AppConfig


class AliveuserConfig(AppConfig):
    name = 'aliveuser'
