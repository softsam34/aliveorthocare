from django.db import models
from datetime import datetime

# Create your models here.
class Registerpatient(models.Model):
	patient_code=models.CharField(max_length=25)
	patient_admit_date=models.DateField(default=datetime.utcnow)
	patient_name=models.CharField(max_length=40)	
	patient_email=models.EmailField(max_length=60, blank=True)
	patient_age=models.IntegerField(default='00',)
	patient_gender=models.CharField(max_length=10, blank=True)
	patient_pincode=models.CharField(max_length=10, blank=True)
	patient_phoneno=models.IntegerField(default="00")
	patient_address=models.TextField(blank=True)
	doctor_name=models.CharField(max_length=100, blank=True)
	doctor_address=models.CharField(max_length=100, blank=True)
	indicator_for=models.CharField(max_length=50)

	class Meta:
		db_table = 'Registerpatient'

class Patientbank(models.Model):
	patient=models.ForeignKey('Registerpatient', default=1, on_delete=models.CASCADE)
	bank_draft_no=models.IntegerField(default="00")
	draft_date=models.DateField(default=datetime.utcnow)
	draft_amount=models.DecimalField(max_digits=20, decimal_places=2)
	draft_drawn_onbank=models.CharField(max_length=100)

	class Meta:
		db_table='Patientbank'

class Timeprocessing(models.Model):
	patient=models.ForeignKey('Registerpatient', default=1, on_delete=models.CASCADE)
	processing_time=models.TimeField()
	processing_type=models.CharField(max_length=100, blank=True)
	processing_total=models.IntegerField(default="00")
	processing_advance=models.IntegerField(default="00")
	Processing_balance=models.IntegerField(default="00")
	processing_reciptno=models.CharField(max_length=20, blank=True)
	processing_billing_normal=models.CharField(max_length=20, blank=True)
	processing_dateBy=models.DateField(default=datetime.utcnow)
	processing_notby=models.CharField(max_length=100, blank=True)
	processing_checkedby=models.CharField(max_length=100, blank=True)

	class Meta:
		db_table='Timeprocessing'
