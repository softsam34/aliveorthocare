from django.shortcuts import render
from django.contrib.auth.models import User, auth
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import Registerpatient, Patientbank, Timeprocessing
from aliveuser import models
from django.db import IntegrityError, transaction



# Create your views here.
def register(request):
	if request.method == 'POST':
		first_name=request.POST['first_name']
		last_name=request.POST['last_name']
		username=request.POST['username']
		password1=request.POST['password1']
		password2=request.POST['password2']
		email=request.POST['email']

		if password1==password2:
			if User.objects.filter(username=username).exists():
				print("username Already Taken")
				messages.info(request,'username Already Taken')
				rs=render(request,'register.html')
				return rs
			elif User.objects.filter(email=email).exists():
				print("Email Id Already Exits")
				messages.info(request,'Email Already Exists')
				rs=render(request,'register.html')
				return rs
			else:
				user=User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)		
				user.save();
				print('user created')
				messages.info(request,'User Created SuccessFully')				
				rs=render(request,'register.html')
				return rs
				
		else:
			print("password not matched")
			messages.info(request,'Password Not matched')
		
		rs=render(request,'register.html')
		return rs

	else:
   		rs=render(request,'register.html')
   		return rs

def login(request):
	if request.method=='POST':
		username=request.POST['username']
		password=request.POST['password']

		user=auth.authenticate(username=username, password=password)

		if user is not None:
			auth.login(request, user)
			return HttpResponseRedirect('dashboard')

		else:
			messages.info(request,'Invalid Credentails')
			rs= render(request,'login.html')
			return rs	

	else:	
		rs= render(request,'login.html')
		return rs


def logout(request):
	auth.logout(request)
	rs=render(request,'/')
	return rs
	
@login_required(login_url="/login")
def logout(request):
	rs=render(request,'dashboard.html')
	return rs
@login_required(login_url="/login")
def patient(request):
	rs=render(request,'patient.html')
	return rs
@login_required(login_url="/login")
def salesform(request):
	rs=render(request,'salesform.html')
	return rs
@transaction.atomic
@login_required(login_url="/login")
def registerpatient(request):
	if request.method=='POST':
		addpatient=models.Registerpatient()
		addpatient.patinet_code=request.POST.get("patientCode")
		addpatient.patient_admit_date=request.POST.get("admitDate")
		addpatient.patient_name=request.POST.get("patientName")
		addpatient.patient_email=request.POST.get("patientEmail")
		addpatient.patient_age=request.POST.get("patientAge")
		addpatient.patient_gender=request.POST.get("patientGender")
		addpatient.patient_pincode=request.POST.get("patientPinCode")
		addpatient.patient_phoneno=request.POST.get("patientPhoneNo")
		addpatient.patient_address=request.POST.get("patientAddress")
		addpatient.doctor_name=request.POST.get("doctorName")
		addpatient.doctor_address=request.POST.get("doctorAddress")
		addpatient.indicator_for=request.POST.get("indicateFor")
		
		addpatient.save()
		sid = transaction.savepoint()

		patientbank=models.Patientbank()
		patientbank.bank_draft_no=request.POST.get("bankDraftNo")
		patientbank.dpatientbankraft_date=request.POST.get("draftDate")
		patientbank.draft_amount=request.POST.get("draftAmount")
		patientbank.draft_drawn_onbank=request.POST.get("draftDrawnBank")
		patientbank.patient_id=addpatient.id
		
		

		patienttimeprocess=models.Timeprocessing()
		patienttimeprocess.patient_id=addpatient.id
		patienttimeprocess.processing_time=request.POST.get("processingTime")
		patienttimeprocess.processing_type=request.POST.get("processingType")
		patienttimeprocess.processing_total=request.POST.get("total")
		patienttimeprocess.processing_advance=request.POST.get("advance")
		patienttimeprocess.Processing_balance=request.POST.get("balance")
		patienttimeprocess.processing_reciptno=request.POST.get("receiptNo")
		patienttimeprocess.processing_billing_normal=request.POST.get("billingNormal")
		patienttimeprocess.processing_dateBy=request.POST.get("dateBy")
		patienttimeprocess.processing_notby=request.POST.get("notedBy")
		patienttimeprocess.processing_checkedby=request.POST.get("checkedBy")
		try:
			patientbank.save()
			patienttimeprocess.save()
			transaction.savepoint_commit(sid)
		except IntegrityError:
			transaction.savepoint_rollback(sid)	
					
		print("Patient Bank Details Save SuccessFully")
		print("Added SuccessFully")
	return HttpResponseRedirect('dashboard')
